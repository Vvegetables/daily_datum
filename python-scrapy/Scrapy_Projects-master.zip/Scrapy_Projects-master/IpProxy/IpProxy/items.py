# -*- coding: utf-8 -*-
#actor

import scrapy

class IpproxyItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    IP = scrapy.Field()
    port = scrapy.Field()
    #status = scrapy.Field()
    #types = scrapy.Field()
    #support = scrapy.Field()
    #address = scrapy.Field()
    #speed = scrapy.Field()
    #testtime = scrapy.Field()
    #grab_time = scrapy.Field()
