# Scrapy Projects

## OnesSpider
该爬虫是将[一个](http://caodan.org)网站上的图片，问题，文章全部抓取下来，预计耗时1个小时，大约1300页面。

## dbMoviesTop250
抓取豆瓣排行前250名电影信息

## JiKeXueYuan
抓取极客学院整站视频, 大约8000多个（侵立删）

## zhiHuSpider
抓取知乎用户信息，主要参考， （侵立删）

## QiuShiBaiKe
抓取糗事百科热门笑话 author, content

## ShiFuTu
抓取十幅图id, title, imgurl 并下载图片

## IpProxy
抓取免费的ip代理

## LitterLove
抓取新片场的小情书系列视频

## DouTu
抓取斗图网站上图片
