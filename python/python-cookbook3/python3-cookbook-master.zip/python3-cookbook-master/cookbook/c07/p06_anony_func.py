#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
Topic: 匿名函数lambda表达式
Desc : 
"""

add = lambda x, y: x + y
print(add(2,3))
