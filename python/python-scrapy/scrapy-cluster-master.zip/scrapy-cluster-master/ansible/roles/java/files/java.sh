# Initialization script for Java
JAVA_HOME="/usr/java/default"
export JAVA_HOME
