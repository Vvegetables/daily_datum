export const HOST = 'http://120.79.162.149:3000'
export const ERR_OK = 200

export const playMode = {
  sequence: 0,
  loop: 1,
  random: 2
}
